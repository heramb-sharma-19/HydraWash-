# FreshFold hero page

The complete code for the laundry landing page with the 3D washing-machine
animation (Wash → Dry → Iron → Pack → Deliver).

## Files

- `src/routes/index.tsx` — the hero page (brand, headline, "Book a pickup"
  button, selling points) with the 3D machine embedded full-screen.
- `src/components/ui/agentic-factory-3d.tsx` — the self-contained 3D machine
  (plain three.js, no React Three Fiber). Renders into a div; supports
  `embed` and `height` props.
- `hero-tokens.css` — the CSS color tokens the page uses
  (`bg-hero`, `text-hero-foreground`, `text-hero-accent`, `bg-hero-accent`).

## Dependencies

```bash
npm install three
npm install -D @types/three
```

The page uses `lucide-react` for icons and `@tanstack/react-router` for the
route definition. If your project uses a different router, keep the `Index`
component and drop the `createFileRoute` wrapper.

## Styles

Merge `hero-tokens.css` into your global CSS. It assumes Tailwind CSS v4
(`@theme` tokens). The 3D canvas has its own dark background, so the page
works on its own without the rest of the site's theme.

## Notes

- The route is marked `ssr: false` because the 3D scene needs a browser.
- The model no longer auto-rotates; users can drag to orbit it.
- The "$29" on the delivery sign and the "made with AI agents" credit line
  are inside `agentic-factory-3d.tsx` — search for `$29` and `vibecoding`
  there if you want to change or remove them.
