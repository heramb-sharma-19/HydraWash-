import { createFileRoute } from "@tanstack/react-router";
import { ArrowRight, Truck, Sparkles, Clock } from "lucide-react";
import AgenticFactory3D from "@/components/ui/agentic-factory-3d";

export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "FreshFold — Laundry Management, Pickup to Delivery" },
      { name: "description", content: "Run your laundry business end to end: online orders, washing, drying, folding and delivery tracked in one system." },
      { property: "og:title", content: "FreshFold — Laundry Management" },
      { property: "og:description", content: "Pickup, wash, dry, fold and deliver — every order tracked in one place." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="relative min-h-screen overflow-hidden bg-hero text-hero-foreground">
      <div className="absolute inset-0">
        <AgenticFactory3D embed height="100vh" />
      </div>
      <nav className="relative z-10 flex items-center justify-between px-6 py-6 md:px-12">
        <span className="text-lg font-semibold tracking-tight">FreshFold</span>
        <a href="#" className="rounded-full border border-hero-foreground/20 px-4 py-2 text-sm hover:bg-hero-foreground/10">Sign in</a>
      </nav>
      <section className="pointer-events-none relative z-10 flex min-h-[calc(100vh-88px)] max-w-xl flex-col justify-center px-6 pb-16 md:px-12">
        <p className="mb-4 text-xs uppercase tracking-[0.25em] text-hero-accent">Laundry management system</p>
        <h1 className="text-4xl font-semibold leading-tight md:text-6xl">From dirty bag to doorstep, on autopilot.</h1>
        <p className="mt-5 text-base text-hero-foreground/70 md:text-lg">
          Take orders, track every load through washing, drying, ironing and packing, and get paid on delivery — all from one dashboard.
        </p>
        <div className="pointer-events-auto mt-8 flex flex-wrap gap-3">
          <a href="#" className="inline-flex items-center gap-2 rounded-full bg-hero-accent px-6 py-3 font-medium text-hero hover:opacity-90">
            Book a pickup <ArrowRight className="h-4 w-4" />
          </a>
        </div>
        <ul className="mt-10 flex flex-wrap gap-6 text-sm text-hero-foreground/70">
          <li className="flex items-center gap-2"><Truck className="h-4 w-4 text-hero-accent" /> Free pickup</li>
          <li className="flex items-center gap-2"><Clock className="h-4 w-4 text-hero-accent" /> 24h turnaround</li>
          <li className="flex items-center gap-2"><Sparkles className="h-4 w-4 text-hero-accent" /> Eco detergents</li>
        </ul>
      </section>
    </main>
  );
}
